function SGMs = Compute_SGM(X)
%calculate single Gaussian model of eath set data

nSam = length(X);
SGMs = cell(nSam,1);
for i = 1 : nSam
    DataSet_i = X{i};   
    % EM calculation
    [SGModel_i, SGModel_i, ~] = emgm(DataSet_i,1);
    SGMs{i}.mu = SGModel_i.mu;
    SGMs{i}.R = SGModel_i.Sigma;
    SGMs{i}.w = SGModel_i.weight;
    
end
