function [Y1_mu, Y1_C] = Compute_Mean_Cov(SY1)
%calculate mean and covariance matrix of each set data

number_sets1=length(SY1);
for tmpC1=1:number_sets1
   % tmpC1
    Y1=SY1{tmpC1};
    y1_mu = mean(Y1,2);
    Y1_mu(:,tmpC1) = y1_mu;
    
    
    Y1 = Y1-repmat(y1_mu,1,size(Y1,2));
    Y1 = Y1*Y1'/(size(Y1,2)-1);
    lamda = 0.001*trace(Y1);    % dealing with non-zero principle element, singularity
    Y1 = Y1+lamda*eye(size(Y1,1)); % dealing with non-zero principle element, singularity
    Y1_C(:,:,tmpC1) = Y1;   
end