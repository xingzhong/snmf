%Grassmannian Graph-Embedding Discriminant Analysis
%
%Projection_Model=GGDA(Kernel_Data,Ww,Wb,Beta)
%       Input:
%           Kernel_Data - Gram matrix. Each element (i,j) represents
%                         the measure of similarity between two points 
%                         ,X_i and X_j, on the Grassmann manifold.
%           Ww - The within-class similarity graph. 
%           Wb - The between-class similarity graph. 
%           Beta - The regularization parameter of the Rayleigh 
%                  quotient (equation 12 of the reference).
%       Output:
%           Projection_Model - A structure stores eigenvectors
%                              and eigenvalues of the solution.
%           Projection_Model.Alpha - Eigenvectors of the solution.
%           Projection_Model.Eig_Values - Eigenvalues of the solution.
%                       
%
%                       
%
%Reference:
%
%   M.T. Harandi, C. Sanderson, S. Shirazi, and B.C. Lovell, 
%   Graph Embedding Discriminant Analysis on Grassmannian Manifold for 
%   Improved Set Matching, CVPR'2011.
% 
%
%   Written by Mehrtash Harandi (mehrtash.harandi@gmail.com)
%
function Projection_Model=GGDA(Kernel_Data,Ww,Wb,Beta)
%Regularization value, it can improve the results.
tmpSigma=1e-1;
    



N=length(Kernel_Data.y);
Number_Class=max(Kernel_Data.y);


I_N=eye(N);

%Generating block diagonal term
V=[];
for tmpC1=1:Number_Class
    num_data_class=length(find(Kernel_Data.y==tmpC1));
    V=blkdiag(V,ones(num_data_class)/num_data_class);
end

%Degree and Laplacian matrices
Db = diag(sum(Wb,2))-diag(diag(Wb));
Lb=Db-Wb;


Dw = diag(sum(Ww,2));



%Projection


SB_W=Lb+Beta*Ww;
SW_W=Dw;

SB = Kernel_Data.X *  (SB_W) * Kernel_Data.X;
SW = Kernel_Data.X *  (SW_W) * Kernel_Data.X+tmpSigma*I_N;



%Solving Rayleigh quotient
Ray_Qoutient= full((SW)\(SB));
[tmpEigVec,tmpEigVal]=eig(Ray_Qoutient);


%Sort the eigenvalues
unsorted_EigVal=diag(tmpEigVal);
[sorted_EigVal,sorted_index]=sort(unsorted_EigVal,'descend');

Projection_Model.Alpha=tmpEigVec(:,sorted_index);
Projection_Model.Eig_Values=sorted_EigVal;




