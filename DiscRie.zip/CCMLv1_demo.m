clear all; close all;
clc;

load(strcat('.\data\KTH'))
disp('Data load success! ');

% data description:
% Gallery.X: gallery data (each cell is a set, whose columns represent single samples)
% Gallery.y: the label of gallery data
% Probe.X: probe data (each column is a sample)
% Probe.y: the label of proble data
% Note: the demo_data is our processed data by employing PCA

disp('Calculating mean and covariance matrix... ');
[M_Gal,C_Gal] = Compute_Mean_Cov(Gallery.X);
[M_Pro,C_Pro] = Compute_Mean_Cov(Probe.X);
disp('Calculating logarithm of covariance matrix... ');
LogC_Gal = Compute_Log_Cov(C_Gal);
LogC_Pro = Compute_Log_Cov(C_Pro);
disp('Calculating single Gaussian model... ');
SGM_Gal = Compute_SGM(Gallery.X);
SGM_Pro = Compute_SGM(Probe.X);
disp('Calculating embedding model... ');
G_Gal = Compute_SGM_Embedding(SGM_Gal);
G_Pro = Compute_SGM_Embedding(SGM_Pro);

n_Ker=3;
disp('Computing kernels...')
K_Gal{1} = M_Gal'*M_Gal;
K_Pro{1} = M_Pro'*M_Gal;
K_Gal{2} = Compute_Riemann_Kernel(LogC_Gal,[]);
K_Pro{2} = Compute_Riemann_Kernel(LogC_Gal,LogC_Pro);
K_Gal{3} = Compute_Riemann_Kernel_Gau(G_Gal,[]);
K_Pro{3} = Compute_Riemann_Kernel_Gau(G_Gal,G_Pro);

disp('Normalizing kernels... ');
n_Gal = length(Gallery.y);
n_Pro = length(Probe.y);
N_Gal=eye(n_Gal)-ones(n_Gal,n_Gal)/n_Gal;
N_Pro=ones(n_Pro,n_Gal)/n_Gal;
K_Gal_n = cell(n_Ker,1);
K_Pro_n = cell(n_Ker,1);
for i = 1 : n_Ker
    K_Pro_n{i} = (K_Pro{i} - N_Pro*K_Gal{i})*N_Gal;
    K_Gal_n{i} = N_Gal*K_Gal{i}*N_Gal;
end


[Ww,Wb]=Generate_Grassmann_Graphs(struct('X',K_Gal_n{3},'y',Gallery.y),7);
Projection_Model=GGDA(struct('X',K_Gal_n{3},'y',Gallery.y),Ww,Wb,1e+1);
% Applying model
FTrain_Proj=Projection_Model.Alpha'*K_Gal_n{3};
FTest_Proj=Projection_Model.Alpha'*K_Pro_n{3};
%Max_Number_Features=size(Projection_Model.Alpha,2);
CRR=myNN(struct('X',FTest_Proj,'y',Probe.y'),struct('X',FTrain_Proj,'y',Gallery.y'))



