function LCY1 = Compute_Log_Cov(CY1)

number_sets1=size(CY1,3);
for tmpC1=1:number_sets1
    Y1=CY1(:,:,tmpC1);   
    LCY1(:,:,tmpC1)= logm(Y1);
end