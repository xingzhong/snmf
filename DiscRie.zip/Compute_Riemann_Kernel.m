function outKernel=Compute_Riemann_Kernel(CY1,CY2)
if(isempty(CY2))
    CY2 = CY1;
end
number_sets1=size(CY1,3);
number_sets2=size(CY2,3);

outKernel=zeros(number_sets1,number_sets2);
for tmpC1=1:number_sets1
        
    Y1=CY1(:,:,tmpC1);
    for tmpC2=1:number_sets2
        Y2=CY2(:,:,tmpC2);    
        outKernel(tmpC1,tmpC2)=trace(Y1*Y2);
    end
end
