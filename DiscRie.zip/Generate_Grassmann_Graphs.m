%Generate within and between similarity graphs for 
%Grassmannian Graph-Embedding Discriminant Analysis
%
%[Ww,Wb]=Generate_Grassmann_Graphs(Grassmann_Kernel,k)
%       Input:
%           Grassmann_Kernel - Similarity between points on the Grassmannian
%                               manifold along point labels in an structure.
%                     Grassmann_Kernel.X(i,j) is the similarity between
%                     points i and j on the Grassmann manifold.
%                     Grassmann_Kernel.y(i) is the label of point i
%                     on the Grassmann manifold.
%           k - Number of neighbors considered for the within similarity graph.
%
%       Output:
%           Ww - Within similarity graph
%           Wb - Between similarity graph
%                       
%
%                       
%
%Reference:
%
%   M.T. Harandi, C. Sanderson, S. Shirazi, and B.C. Lovell, 
%   Graph Embedding Discriminant Analysis on Grassmannian Manifold for 
%   Improved Set Matching, CVPR'2011.
% 
%
%   Written by Mehrtash Harandi (mehrtash.harandi@gmail.com)
%

function [Ww,Wb]=Generate_Grassmann_Graphs(Grassmann_Kernel,k)
N=length(Grassmann_Kernel.y);
Ww = zeros(N);
Wb = zeros(N);

for tmpC1=1:N
    l_i=Grassmann_Kernel.y(tmpC1);
    tmpDistanceW=Grassmann_Kernel.X(Grassmann_Kernel.y==l_i,tmpC1);
    sorted_valW=sort(tmpDistanceW,'descend');
    tmpDistanceB=Grassmann_Kernel.X(Grassmann_Kernel.y~=l_i,tmpC1);
    sorted_valB=sort(tmpDistanceB,'descend');
    for tmpC2=1:N
        l_j=Grassmann_Kernel.y(tmpC2);
        
        %Within graph
        if (l_i==l_j)
            if (Grassmann_Kernel.X(tmpC1,tmpC2)>=sorted_valW(min(end,k)))
                Ww(tmpC1,tmpC2)=1;
                Ww(tmpC2,tmpC1)=1;
            end
        else
            %Between graph
            if (Grassmann_Kernel.X(tmpC1,tmpC2)>=sorted_valB(max(end-k+1,1)))
                Wb(tmpC1,tmpC2)=1;
                Wb(tmpC2,tmpC1)=1;
            end
        end
    end
    
    
end



