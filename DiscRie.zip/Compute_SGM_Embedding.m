function Y1_T = Compute_SGM_Embedding(SY1)
%calculate embedding model for each single Gaussian model 


number_sets1=length(SY1);
Y1_T = cell(number_sets1,1);
for tmpC1=1:number_sets1
    Y1=SY1{tmpC1};
    Y1_mu = Y1.mu;
    Y1_cov = Y1.R;
    num_gau = size(Y1_mu,2);
    Y1_T{tmpC1}.T = cell(num_gau,1);
    Y1_T{tmpC1}.W = Y1.w;
    for i = 1 : size(Y1_mu,2)
        y1_m= Y1_mu(:,i);         
        y1_c = Y1_cov(:,:,i);        
        lamda = 0.001*trace(y1_c); 
        y1_c = y1_c+lamda*eye(size(y1_c,1)); %regularization        
        
        %embedding of Gaussian component 
        % y1_t = det(y1_c)^(-1/(size(y1_c,1)+1))*[y1_c+y1_m*y1_m' y1_m;y1_m' 1];
        y1_t = [y1_c+y1_m*y1_m' y1_m;y1_m' 1];    
        Y1_T{tmpC1}.T{i} = logm(y1_t); %logarithm
    end    % for 1 Image in the image set SY1, it is expanded with N Gaussian means, into N set of statistic. 1 Image--N log set
end