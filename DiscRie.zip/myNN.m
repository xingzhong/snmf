function [CRR,y_hat]=myNN(Test_Data,Train_Data)
Number_Samples=length(Test_Data.y);
Number_Train_Samples=length(Train_Data.y);
y_hat=zeros(1,Number_Samples);
for tmpC1 = 1:Number_Samples
    D=sum(abs(Train_Data.X-repmat(Test_Data.X(:,tmpC1),[1 Number_Train_Samples])),1);
    [junk1,tmpInd]=min(D);
    y_hat(tmpC1) = Train_Data.y(tmpInd);

end

CRR=1-length(find((y_hat-Test_Data.y)~=0))/Number_Samples;
