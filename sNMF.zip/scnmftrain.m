function [F,G,Ec] = scnmftrain(X,El,kt,alpha,gamma,smallval,itermax)

[d,n]=size(X);

%[labelkt,Cenkt] = kmeans(X',kt);
[Centkt,~,labelkt] = SVDinitSemiNMF(X,kt); 
G=zeros(kt,n);
for ii=1:n
    [val,ind]=max(labelkt(:,ii));
    G(ind,ii)=1;
   % G(labelkt(ii),ii)=1;
end
G(G==0)=G(G==0)+smallval;
F=X*G';
Ec=El*G';
fval=norm(X-F*G,'fro')^2+alpha*norm(Ec-El*G','fro')+gamma*norm(F-X*G','fro');
iter=0; tol=10^(-4);
while iter<itermax 
    val=fval;
    if mod(iter,500)==0
        fprintf('it=%3d  f=%.5f',iter,val); fprintf('\n');
    end
    A=(1+gamma).*F'*X+alpha.*Ec'*El; % the final matrice multiplication is with kt row n col
    B1=F'*F;B2=alpha.*El'*El+gamma.*X'*X;
    posA=part(A,1);negA=part(A,0);
    negB1G=part(B1,0)*G; posB1G=part(B1,1)*G;
    negB2G=G*part(B2,0); posB2G=G*part(B2,1);
    G=G.*sqrt( (posA+negB1G+negB2G)./(negA+posB1G+posB2G) );
    F=X*G';
    Ec=El*G';
    fval=norm(X-F*G,'fro')^2+alpha*norm(Ec-El*G','fro')+gamma*norm(F-X*G','fro');
    if (abs(fval-val)<tol)
        break;
    end
    iter =iter+1;
end


function Apar=part(A,np)
if np
    Apar=(abs(A)+A)./2;
else
    Apar=(abs(A)-A)./2;
end


