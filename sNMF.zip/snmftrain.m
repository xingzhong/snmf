function [init_G,F,G,Ec] = snmftrain(X,El,kt,alpha,smallval,itermax)
% Input:
% smallval- a small value overcoming 0 label in matrix G
% X- d*n n samples(data instances) d dimension
% El- ke*n ke emotion labels for n samples
% alpha- weight for emotion label regularization term
% kt- Number of topic clusters
% Output:
% F- d*kt kt topic cluster centrodis with for samples with d dimension 
% G- kt*n kt topic cluster label for n samples
% Ec- ke*kt Emotion value codebook for ke emotion cluster to kt topics clusters
% 
% Ec= El*G'; X=FG
%

[d,n]=size(X);
ke=size(El,2);
%[labelkt,Cenkt] = kmeans(X',kt);
[Cenkt,~,labelkt] = SVDinitSemiNMF(X,kt); 
G=zeros(kt,n);
for ii=1:n
    [val,ind]=max(labelkt(:,ii));
    G(ind,ii)=1;
%    G(labelkt(ii),ii)=1;
end
G(G==0)=G(G==0)+smallval;
init_G=G;
F=X*G'*pinv(G*G');
Ec=El*G';

fval=norm(X-F*G,'fro')^2+alpha*(norm(Ec-El*G','fro')^2);
iter=0; tol=10^(-4);de=0;
while iter<itermax 
    val=fval;

    if mod(iter,500)==0
        fprintf('it=%3d  f=%.5f gn=%.5f',iter,val,de); fprintf('\n');
    end

    F=X*G'*pinv(G*G');
    Ec=El*G';
    
    a=F'*X+alpha.*Ec'*El; % the final matrice multiplication is with kt row n col
    b1=F'*F;b2=El'*El;
    posa=part(a,1);nega=part(a,0);
    negb1G=part(b1,0)*G; posb1G=part(b1,1)*G;
    negGb2=G*part(b2,0); posGb2=G*part(b2,1);
    G=G.*sqrt( (posa+negb1G+alpha.*negGb2)./(nega+posb1G+alpha.*posGb2) );
    fval=norm(X-F*G,'fro')^2+alpha*(norm(Ec-El*G','fro')^2);
    de=abs(fval-val);
    if (de<tol)
        break;
    end
    iter =iter+1;
end


function Apar=part(A,np)
if np
    Apar=(abs(A)+A)./2;
else
    Apar=(abs(A)-A)./2;
end






