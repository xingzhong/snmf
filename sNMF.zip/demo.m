clear all;close all;clc;

% load data and parameter settings
load('wfrq2.mat')
%load('imshistgray.mat')
%table=cellstr(tab);
%table=tab;
half=ceil(length(y)/2);
total=length(y);

y=y+1;
ke=length(unique(y));
El = zeros(ke,length(y));
for i=1:length(y)
    El(y(i),i)=1;
end


kt=30;    %Number of Latent topics (the more the better)
smallval=0.2; % 0 prevention of latent topic label matrix G
alphatr=10;  % parameter for emotion level feedback energy term
gamma=10; % Penalty parameter for clustering NMF
itermax=10000; % Max iteration number, iteration will stop if either reach max iteration or tolerance

disp('Training supervised NMF feat...')
[init_G,F,G,Ec] = snmftrain(X(:,1:800),El(:,1:800),kt,alphatr,smallval,itermax);
%disp('Training supervised clustering NMF feat...')
%[F,G,Ec] = scnmftrain(X(:,1:1000),El(:,1:1000),kt,alphatr,gamma,smallval,itermax);
%disp('Training SVM...')
%svmmodel = svmtrain(y', X', '-c 5 -b 1');
%disp('Clustering emotion NMF feat...')
%[F,Gout,Ec,Elout] = enmfcluster(X,ke,kt,alphatr,smallval);

%Classification
disp('Classification...')
Gout=pinv(F)*X(:,801:1000);
Elout=Ec*Gout*pinv(Gout'*Gout);
[val,ind]=max(Elout);
ncorrect=sum(y(801:1000)==ind);
frate=ncorrect/length(ind);
Ec

disp(strcat('Classification rate of supervised NMF:'));
disp('')
fprintf('Accuracy=%.4f%% (%4d/%4d)(classification)',frate*100,ncorrect,length(ind))
[val,indt]=max(F');
topics=unique(indt);
for p=1:length(topics)     
    twords{p}=table(find(indt==topics(p)));
end
save('.\output\etwords.mat','twords','Ec','G','F');
%disp('Classification rate of SVM:')
%[predict_label, accuracy, dec_values] = svmpredict(yte', Xte', svmmodel);
%fsvmrate=max(accuracy)/100

